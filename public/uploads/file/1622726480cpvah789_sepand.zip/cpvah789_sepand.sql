/*
 Navicat Premium Data Transfer

 Source Server         : majidi
 Source Server Type    : MySQL
 Source Server Version : 100322
 Source Host           : vahidmajidi.com:3306
 Source Schema         : cpvah789_sepand

 Target Server Type    : MySQL
 Target Server Version : 100322
 File Encoding         : 65001

 Date: 17/05/2021 00:36:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for airline
-- ----------------------------
DROP TABLE IF EXISTS `airline`;
CREATE TABLE `airline`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `thumbnail` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `slug`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of airline
-- ----------------------------
INSERT INTO `airline` VALUES (11, 2, 'ترکیش ایرلاین', 'ترکیش-ایرلاین', '20-205276_transparent-airplane-logo-png-turkish-airlines-logo-svg.png', '2021-05-15 17:05:00', '2021-05-16 22:40:32');
INSERT INTO `airline` VALUES (12, 2, 'قطر ایرلاین', 'قطر-ایرلاین', 'Qatar-Airways-Logo.png', '2021-05-16 22:42:13', '2021-05-16 22:42:13');

-- ----------------------------
-- Table structure for blog_category
-- ----------------------------
DROP TABLE IF EXISTS `blog_category`;
CREATE TABLE `blog_category`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `show` tinyint(1) NULL DEFAULT 1,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `slug`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of blog_category
-- ----------------------------
INSERT INTO `blog_category` VALUES (1, 2, 'تورها داخلی', 'تورها-داخلی', 1, '2021-04-27 16:41:23', '2021-05-10 11:51:56');

-- ----------------------------
-- Table structure for blog_tag
-- ----------------------------
DROP TABLE IF EXISTS `blog_tag`;
CREATE TABLE `blog_tag`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `show` tinyint(1) NULL DEFAULT 1,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `slug`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of blog_tag
-- ----------------------------
INSERT INTO `blog_tag` VALUES (20, 2, 'test_1', 'aas', 1, '2021-05-16 19:17:06', '2021-05-16 19:17:06');
INSERT INTO `blog_tag` VALUES (21, 2, 'test', 'aasfdrgdrg', 1, '2021-05-16 19:17:14', '2021-05-16 19:17:14');

-- ----------------------------
-- Table structure for bookmark
-- ----------------------------
DROP TABLE IF EXISTS `bookmark`;
CREATE TABLE `bookmark`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` datetime(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of bookmark
-- ----------------------------
INSERT INTO `bookmark` VALUES (1, 5, 4, '2021-03-26 20:20:23');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NULL DEFAULT NULL,
  `product_id` bigint NULL DEFAULT NULL,
  `comment` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `reply_id` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `approved_at` datetime(0) NULL DEFAULT NULL,
  `reply_email` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime(0) NOT NULL,
  `delete` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (2, 2, 2, 'چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.', NULL, 1, '2021-03-30 17:42:07', 0, '2021-03-30 17:42:13', 0, NULL);
INSERT INTO `comment` VALUES (3, 2, 4, 'لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. ', NULL, 1, '2021-03-31 16:18:37', 0, '2021-03-30 18:12:03', 0, NULL);
INSERT INTO `comment` VALUES (4, 1, 2, 'پاسخ شماره یک به تور شماره 2', '2', 1, '2021-03-31 17:55:26', 0, '2021-03-31 17:51:28', 0, NULL);
INSERT INTO `comment` VALUES (7, 2, 2, 'پاسخ به پاسخ', '4', 1, '2021-04-01 12:45:22', 0, '2021-03-31 18:19:51', 0, NULL);
INSERT INTO `comment` VALUES (14, 2, 5, 'به نظرم تور خوبیه!', NULL, 1, '2021-03-31 23:22:21', 0, '2021-03-31 23:13:21', 0, NULL);
INSERT INTO `comment` VALUES (15, 1, 5, 'آره میتونه', '14', 1, '2021-03-31 23:22:16', 0, '2021-03-31 23:17:45', 0, NULL);
INSERT INTO `comment` VALUES (21, 2, 5, 'dyhrth', NULL, 0, '2021-04-01 12:45:16', 0, '2021-03-31 23:36:23', 1, '2021-04-01 12:50:27');
INSERT INTO `comment` VALUES (22, 1, 3, 'با سلام عالیه', NULL, 1, NULL, 0, '2021-04-06 17:05:32', 0, NULL);
INSERT INTO `comment` VALUES (23, 1, 1, 'سلام خوبی', NULL, 1, NULL, 0, '2021-04-06 17:18:06', 0, NULL);
INSERT INTO `comment` VALUES (24, 1, 1, 'چرت میگه', '23', 1, NULL, 0, '2021-04-06 17:18:43', 0, NULL);
INSERT INTO `comment` VALUES (25, 2, 3, 'زر نزن', '22', 0, NULL, 0, '2021-04-09 16:14:05', 1, '2021-04-10 23:03:27');
INSERT INTO `comment` VALUES (26, 2, 3, 'زر نزن', '22', 0, NULL, 0, '2021-04-09 16:14:11', 1, '2021-04-10 23:03:20');

-- ----------------------------
-- Table structure for contact
-- ----------------------------
DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created_at` datetime(0) NOT NULL,
  `seen` tinyint(1) NULL DEFAULT 0,
  `seen_who` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `seen_at` datetime(0) NULL DEFAULT NULL,
  `answer` tinyint(1) NULL DEFAULT 0,
  `answer_text` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `answer_at` datetime(0) NULL DEFAULT NULL,
  `answer_who` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of contact
-- ----------------------------
INSERT INTO `contact` VALUES (1, 3, 'محمد', 'dh.hs56@yahoo.com', '', NULL, ' موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی', '2021-05-06 12:57:08', 1, '2', '2021-05-10 12:26:02', 0, NULL, NULL, NULL);
INSERT INTO `contact` VALUES (2, 1, 'علی', 'novinnetran@gmail.com', '09126764539', NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip', '2021-03-31 11:27:17', 1, '2', '2021-05-10 15:27:23', 1, 'asdasdasdsad', '2021-05-03 23:24:15', '2');
INSERT INTO `contact` VALUES (3, 2, 'حمیدرضا', 'hr.ahmadi689@yahoo.com', '09193109312', NULL, 'لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی', '2021-05-06 11:28:54', 1, '2', '2021-05-16 22:45:52', 1, 'پاسخ خود را اینجا بنویسید', '2021-05-04 11:42:08', '2');
INSERT INTO `contact` VALUES (4, NULL, 'sadasdasd', 'asd@yahoo.com', '09369100696', NULL, 'salam', '2021-05-06 20:25:42', 1, '2', '2021-05-17 00:09:49', 1, 'پاسخ خود را اینجا بنویسید', '2021-05-04 11:22:42', '2');

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp(0) NOT NULL DEFAULT current_timestamp(0),
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `failed_jobs_uuid_unique`(`uuid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of failed_jobs
-- ----------------------------

-- ----------------------------
-- Table structure for jobs
-- ----------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED NULL DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `jobs_queue_index`(`queue`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 161 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of jobs
-- ----------------------------

-- ----------------------------
-- Table structure for like
-- ----------------------------
DROP TABLE IF EXISTS `like`;
CREATE TABLE `like`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `created_at` datetime(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of like
-- ----------------------------

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2019_08_19_000000_create_failed_jobs_table', 1);
INSERT INTO `migrations` VALUES (2, '2021_01_19_103654_create_jobs_table', 1);

-- ----------------------------
-- Table structure for newsletters
-- ----------------------------
DROP TABLE IF EXISTS `newsletters`;
CREATE TABLE `newsletters`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  `delete` tinyint(1) NULL DEFAULT 0,
  `user_id` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of newsletters
-- ----------------------------
INSERT INTO `newsletters` VALUES (1, 'hr.ahmadi689@yahoo.com', '2021-04-06 13:47:04', '2021-04-06 13:47:04', NULL, 0, NULL);
INSERT INTO `newsletters` VALUES (2, 'hr.ahmadi6722@gmail.com', '2021-04-06 13:50:08', '2021-04-06 14:26:50', '0000-00-00 00:00:00', 0, 2);

-- ----------------------------
-- Table structure for posts
-- ----------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `category_id` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tag_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `thumbnail` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `view` bigint NULL DEFAULT 0,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `show` tinyint(1) NULL DEFAULT 1,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `slug`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of posts
-- ----------------------------
INSERT INTO `posts` VALUES (2, 1, 'تست', 'تست', '[1,1]', '[17,18]', 'blog-post-01.jpg', 0, '<p>شسبشسیبسش</p>', 1, '2021-04-28 21:52:35', '2021-05-02 20:20:23');
INSERT INTO `posts` VALUES (3, 1, 'تسیبعسیغباغسیاغاسیغا', 'تسیبعسیغباغسیاغاسیغا', '[1]', '[11,12,13,14,15]', 'blog-widget-01.jpg', 0, '<p>eryerytert</p>', 1, '2021-04-28 22:37:05', '2021-04-28 22:37:05');

-- ----------------------------
-- Table structure for profile
-- ----------------------------
DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `family` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `telegram` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `whatsapp` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `instagram` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `company` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `avatar` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `melli_cart` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `melli_cart_image` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `website` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bank_cart_number` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bank_account_number` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bank_sheba_number` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bank_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bank_cheque_image` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `company_rooznameh_rasmi_image` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `company_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `referrer_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `referrer_phone` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `referrer_internal_number` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shop_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `shop_javaz_image` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `business_card_image` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `verified_type` tinyint(1) NULL DEFAULT NULL,
  `verified_type_at` datetime(0) NULL DEFAULT NULL,
  `gender` tinyint NULL DEFAULT NULL,
  `birthday` date NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `user_id`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of profile
-- ----------------------------
INSERT INTO `profile` VALUES (1, 1, 'وحید', 'مجیدی صدر', '02177470591', NULL, NULL, NULL, 'داده پردازان ایران', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `profile` VALUES (2, 2, 'حمیدرضا', 'احمدی زاده', '12345678', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for reserve
-- ----------------------------
DROP TABLE IF EXISTS `reserve`;
CREATE TABLE `reserve`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `passengers` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 9 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of reserve
-- ----------------------------
INSERT INTO `reserve` VALUES (1, 2, 4, 'حمیدرضا احمدی زاده', '09193109312', 'tour', '2021-04-09 20:48:43', '1');
INSERT INTO `reserve` VALUES (8, 2, 1, 'حمیدرضا احمدی زاده', '09193109312', 'tour', '2021-04-28 14:38:05', '4');
INSERT INTO `reserve` VALUES (6, 1, 5, 'وحید مجیدی', '09369100696', 'tour', '2021-04-11 16:21:14', '1');
INSERT INTO `reserve` VALUES (5, 1, 4, 'وحید مجیدی', '09369100696', 'tour', '2021-04-10 09:37:21', '1');

-- ----------------------------
-- Table structure for setting
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `header_icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `header_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `header_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `footer_icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `footer_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `footer_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `footer_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `footer_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `copyright` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of setting
-- ----------------------------
INSERT INTO `setting` VALUES (1, 'Untitled-1.png', '02141209000', 'پاسداران نبش نارنجستان 4 مجتمع اداری آرتمیس طبقه 12 واحد 6', 'footer_sepand_logo.png', '021-41209000', 'پاسداران نبش نارنجستان 4 مجتمع اداری آرتمیس طبقه 12 واحد 6', 'info@sepandparvaz.com', 'به سایت ما خوش آمدید!\r\n\r\nبرنامه ریزی برای سفر و انجام رزروها صرفاً برای داشتن کمی استراحت و آرامش ، کار زیادی به نظر می رسد.\r\nشما به جای درست آمده اید!\r\nبرای یک پیشنهاد رایگان با ما تماس بگیرید تا در تعطیلات رویایی خود باشید...', 'تمام حقوق وب سایت متعلق به آژانس هواپیمایی سپند پرواز شرق می باشد.');

-- ----------------------------
-- Table structure for tour
-- ----------------------------
DROP TABLE IF EXISTS `tour`;
CREATE TABLE `tour`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `duration` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `capacity` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `category_id` bigint NULL DEFAULT NULL,
  `price` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `airline` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `thumbnail` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `slider` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `view` bigint NULL DEFAULT 0,
  `special` tinyint(1) NOT NULL DEFAULT 0,
  `high_rank` tinyint(1) NOT NULL DEFAULT 0,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `info` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `facility` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `food` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `tip` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `lat` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `lon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `discount` decimal(20, 0) NULL DEFAULT 0,
  `show` tinyint(1) NULL DEFAULT 1,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `kind` tinyint(1) NULL DEFAULT NULL,
  `special_home_page` tinyint(1) NULL DEFAULT 0,
  `plan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `slug`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tour
-- ----------------------------
INSERT INTO `tour` VALUES (5, 1, 'تور استانبول', 'تور-استانبول', 'دو شب و سه روز', '19', 1, '110 یورو + هزینه بلیط', '11', 'p4.jpg', 'tour-detail.jpg', 0, 1, 1, '<div id=\"information\" class=\"gdlr-core-pbf-column gdlr-core-column-60 gdlr-core-column-first\">\r\n<div class=\"gdlr-core-pbf-column-content-margin gdlr-core-js  text-block-card\">\r\n<div class=\"gdlr-core-pbf-column-content clearfix gdlr-core-js \">\r\n<div class=\"gdlr-core-pbf-element\">\r\n<div class=\"gdlr-core-text-box-item gdlr-core-item-pdlr gdlr-core-item-pdb gdlr-core-right-align\">\r\n<div class=\"gdlr-core-text-box-item-content\">\r\n<ul>\r\n<li>تورها چارتر و غیر قابل استرداد می‌باشد.</li>\r\n<li>پرداخت 50٪ از مبلغ تور هنگام عقد قرارداد الزامی می‌باشد.</li>\r\n<li>\r\n<section id=\"packages\" class=\"sec active\">\r\n<div class=\"tour-packages\" data-tabindex=\"packages-box\">\r\n<div class=\"container\">\r\n<div class=\"content\">\r\n<ul class=\"content__info-list\">\r\n<li>تور استانبول به صورت فردی برگزار می‌شود و مسافران می‌توانند بر اساس برنامه‌ریزی سفر خود، تاریخ پرواز و هتل را انتخاب کنند.</li>\r\n<li>اکثر هتل‌های 3 ستاره شهر استانبول از کیفیت بالایی برخوردار نیستند، بنابراین هنگام انتخاب هتل دقت لازم را داشته باشید.</li>\r\n<li>کودک بدون تخت در برخی از هتل ها تا 5 سال و در برخی هتل ها تا 6 سال به مبلغ 20$ می‌باشد.</li>\r\n<li>نرخ پرواز به صورت جداگانه محاسبه می‌گردد.</li>\r\n<li>انجام تست PCR قبل و بعد از سفر برای تمامی مسافرین الزامی است.</li>\r\n<li>هزینه عوارض خروج از کشور در سفر اول برای هر نفر 264,000 هزار تومان است. این هزینه در سفر دوم 50% و در سفرهای سوم و بیشتر 100% افزایش پیدا می‌کند.</li>\r\n<li>برای رزرو سایر هتل‌های استانبول با کارشناسان ما در واحد تور در تماس باشید.</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<section id=\"call-2-action\" class=\"sec\">\r\n<div class=\"container\">\r\n<div class=\"call-to-action col-lg-19 col-sm-24 col-md-19\"> </div>\r\n</div>\r\n</section>\r\n</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div id=\"recommended-tours\" class=\"gdlr-core-pbf-column gdlr-core-column-60 gdlr-core-column-first\">\r\n<div class=\"gdlr-core-pbf-column-content-margin gdlr-core-js  text-block-card\">\r\n<div class=\"gdlr-core-pbf-column-content clearfix gdlr-core-js \"> </div>\r\n</div>\r\n</div>', '{\"key\":[\"\\u0635\\u0628\\u062d\\u0627\\u0646\\u0647\",\"\\u062a\\u0631\\u0627\\u0646\\u0633\\u0641\\u0631 \\u0641\\u0631\\u0648\\u062f\\u06af\\u0627\\u0647\\u06cc\",\"\\u0628\\u0644\\u06cc\\u0637 \\u0631\\u0641\\u062a \\u0648 \\u0628\\u0631\\u06af\\u0634\\u062a\",\"\\u06af\\u0634\\u062a \\u0634\\u0647\\u0631\\u06cc \\u0647\\u0645\\u0631\\u0627\\u0647 \\u0628\\u0627 \\u0646\\u0647\\u0627\\u0631\",\"\\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u0627\\u0632 \\u06af\\u0634\\u062a \\u0622\\u067e\\u0634\\u0646\\u0627\\u0644\"],\"value\":[\"\\u0631\\u0627\\u06cc\\u06af\\u0627\\u0646\",\"\\u062f\\u0627\\u0631\\u062f\",\"\\u062f\\u0627\\u0631\\u062f\",\"\\u062f\\u0627\\u062e\\u0644 \\u0634\\u0647\\u0631\",\"\\u0628\\u0631 \\u0639\\u0647\\u062f\\u0647 \\u062e\\u0648\\u062f \\u0634\\u0645\\u0627\"]}', '[\"\\u0645\\u0633\\u062c\\u062f \\u0627\\u06cc\\u0627\\u0635\\u0648\\u0641\\u06cc\\u0647\",\"\\u0645\\u0633\\u062c\\u062f \\u0622\\u0628\\u06cc\",\"\\u0628\\u0631\\u062c \\u06af\\u0627\\u0644\\u0627\\u062a\\u0627\",\"\\u06a9\\u0627\\u062e \\u062f\\u0648\\u0644\\u0645\\u0647 \\u0628\\u0627\\u063a\\u0686\\u0647\",\"\\u0645\\u0633\\u062c\\u062f \\u0631\\u0633\\u062a\\u0645 \\u067e\\u0627\\u0634\\u0627\",\"\\u06a9\\u0627\\u062e \\u062a\\u0648\\u067e\\u06a9\\u0627\\u067e\\u06cc\",\"\\u0628\\u0627\\u0632\\u0627\\u0631 \\u0628\\u0632\\u0631\\u06af \\u0627\\u0633\\u062a\\u0627\\u0646\\u0628\\u0648\\u0644\",\"\\u0622\\u0628 \\u0627\\u0646\\u0628\\u0627\\u0631 \\u0628\\u0627\\u0633\\u06cc\\u0644\\u06cc\\u06a9\\u0627\",\"\\u06a9\\u0644\\u06cc\\u0633\\u0627\\u06cc \\u0686\\u0648\\u0631\\u0627\",\"\\u0642\\u0644\\u0639\\u0647 \\u06cc\\u062f\\u06cc\\u06a9\\u0648\\u0644\\u0647\"]', '[\"\\u063a\\u0630\\u0627\\u06cc 1\",\"\\u063a\\u0630\\u0627\\u06cc 2\",\"\\u063a\\u0630\\u0627\\u06cc 3\",\"\\u063a\\u0630\\u0627\\u06cc 4\",\"\\u063a\\u0630\\u0627\\u06cc 5\"]', '[\"\\u0646\\u06a9\\u062a\\u0647 1\",\"\\u0646\\u06a9\\u062a\\u0647 2\",\"\\u0646\\u06a9\\u062a\\u0647 3\",\"\\u0646\\u06a9\\u062a\\u0647 4\"]', '41.01034116009469', '28.973941711905365', 5, 1, '2021-05-16 23:46:50', '2021-05-17 00:21:47', 1, 1, '{\"key\":[\"\\u0631\\u0648\\u0632 \\u0627\\u0648\\u0644\",\"\\u0631\\u0648\\u0632 \\u062f\\u0648\\u0645\",\"\\u0631\\u0648\\u0632 \\u0633\\u0648\\u0645\"],\"value\":[\"\\u062a\\u0648\\u0631 \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0641\\u0631\\u062f\\u06cc \\u0628\\u0631\\u06af\\u0632\\u0627\\u0631 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f \\u0648 \\u0634\\u0645\\u0627 \\u0645\\u06cc\\u200c\\u062a\\u0648\\u0627\\u0646\\u06cc\\u062f \\u0628\\u0631 \\u0627\\u0633\\u0627\\u0633 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647\\u200c\\u0631\\u06cc\\u0632\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062e\\u0648\\u062f \\u0632\\u0645\\u0627\\u0646 \\u0633\\u0641\\u0631 \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f.\\r\\n\\u0632\\u0645\\u0627\\u0646 \\u0635\\u062f\\u0648\\u0631 \\u0648\\u06cc\\u0632\\u0627 \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f 3 \\u0631\\u0648\\u0632 \\u06a9\\u0627\\u0631\\u06cc \\u0627\\u0633\\u062a.\\r\\n\\u0633\\u0641\\u0627\\u0631\\u062a \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f \\u062f\\u0631 \\u0631\\u0648\\u0632\\u0647\\u0627\\u06cc \\u062c\\u0645\\u0639\\u0647 \\u0648 \\u0634\\u0646\\u0628\\u0647 \\u062a\\u0639\\u0637\\u06cc\\u0644 \\u0627\\u0633\\u062a.\\r\\n\\u062a\\u0648\\u0631\\u0647\\u0627\\u06cc \\u0627\\u06cc\\u0646 \\u0645\\u0642\\u0635\\u062f \\u062f\\u0631 \\u062d\\u0627\\u0644 \\u062d\\u0627\\u0636\\u0631 \\u0628\\u0647 \\u062f\\u0644\\u06cc\\u0644 \\u0634\\u06cc\\u0648\\u0639 \\u0648\\u06cc\\u0631\\u0648\\u0633 \\u06a9\\u0631\\u0648\\u0646\\u0627 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0646\\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f. \\u0642\\u06cc\\u0645\\u062a \\u0647\\u0627 \\u0645\\u0631\\u0628\\u0648\\u0637 \\u0628\\u0647 \\u0632\\u0645\\u0633\\u062a\\u0627\\u0646 98\\u0645\\u06cc \\u0628\\u0627\\u0634\\u062f.\",\"\\u062a\\u0648\\u0631 \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0641\\u0631\\u062f\\u06cc \\u0628\\u0631\\u06af\\u0632\\u0627\\u0631 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f \\u0648 \\u0634\\u0645\\u0627 \\u0645\\u06cc\\u200c\\u062a\\u0648\\u0627\\u0646\\u06cc\\u062f \\u0628\\u0631 \\u0627\\u0633\\u0627\\u0633 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647\\u200c\\u0631\\u06cc\\u0632\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062e\\u0648\\u062f \\u0632\\u0645\\u0627\\u0646 \\u0633\\u0641\\u0631 \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f.\\r\\n\\u0632\\u0645\\u0627\\u0646 \\u0635\\u062f\\u0648\\u0631 \\u0648\\u06cc\\u0632\\u0627 \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f 3 \\u0631\\u0648\\u0632 \\u06a9\\u0627\\u0631\\u06cc \\u0627\\u0633\\u062a.\\r\\n\\u0633\\u0641\\u0627\\u0631\\u062a \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f \\u062f\\u0631 \\u0631\\u0648\\u0632\\u0647\\u0627\\u06cc \\u062c\\u0645\\u0639\\u0647 \\u0648 \\u0634\\u0646\\u0628\\u0647 \\u062a\\u0639\\u0637\\u06cc\\u0644 \\u0627\\u0633\\u062a.\\r\\n\\u062a\\u0648\\u0631\\u0647\\u0627\\u06cc \\u0627\\u06cc\\u0646 \\u0645\\u0642\\u0635\\u062f \\u062f\\u0631 \\u062d\\u0627\\u0644 \\u062d\\u0627\\u0636\\u0631 \\u0628\\u0647 \\u062f\\u0644\\u06cc\\u0644 \\u0634\\u06cc\\u0648\\u0639 \\u0648\\u06cc\\u0631\\u0648\\u0633 \\u06a9\\u0631\\u0648\\u0646\\u0627 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0646\\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f. \\u0642\\u06cc\\u0645\\u062a \\u0647\\u0627 \\u0645\\u0631\\u0628\\u0648\\u0637 \\u0628\\u0647 \\u0632\\u0645\\u0633\\u062a\\u0627\\u0646 98\\u0645\\u06cc \\u0628\\u0627\\u0634\\u062f.\",\"\\u062a\\u0648\\u0631 \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0641\\u0631\\u062f\\u06cc \\u0628\\u0631\\u06af\\u0632\\u0627\\u0631 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f \\u0648 \\u0634\\u0645\\u0627 \\u0645\\u06cc\\u200c\\u062a\\u0648\\u0627\\u0646\\u06cc\\u062f \\u0628\\u0631 \\u0627\\u0633\\u0627\\u0633 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647\\u200c\\u0631\\u06cc\\u0632\\u06cc\\u200c\\u0647\\u0627\\u06cc \\u062e\\u0648\\u062f \\u0632\\u0645\\u0627\\u0646 \\u0633\\u0641\\u0631 \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f.\\r\\n\\u0632\\u0645\\u0627\\u0646 \\u0635\\u062f\\u0648\\u0631 \\u0648\\u06cc\\u0632\\u0627 \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f 3 \\u0631\\u0648\\u0632 \\u06a9\\u0627\\u0631\\u06cc \\u0627\\u0633\\u062a.\\r\\n\\u0633\\u0641\\u0627\\u0631\\u062a \\u062a\\u0627\\u06cc\\u0644\\u0646\\u062f \\u062f\\u0631 \\u0631\\u0648\\u0632\\u0647\\u0627\\u06cc \\u062c\\u0645\\u0639\\u0647 \\u0648 \\u0634\\u0646\\u0628\\u0647 \\u062a\\u0639\\u0637\\u06cc\\u0644 \\u0627\\u0633\\u062a.\\r\\n\\u062a\\u0648\\u0631\\u0647\\u0627\\u06cc \\u0627\\u06cc\\u0646 \\u0645\\u0642\\u0635\\u062f \\u062f\\u0631 \\u062d\\u0627\\u0644 \\u062d\\u0627\\u0636\\u0631 \\u0628\\u0647 \\u062f\\u0644\\u06cc\\u0644 \\u0634\\u06cc\\u0648\\u0639 \\u0648\\u06cc\\u0631\\u0648\\u0633 \\u06a9\\u0631\\u0648\\u0646\\u0627 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0646\\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f. \\u0642\\u06cc\\u0645\\u062a \\u0647\\u0627 \\u0645\\u0631\\u0628\\u0648\\u0637 \\u0628\\u0647 \\u0632\\u0645\\u0633\\u062a\\u0627\\u0646 98\\u0645\\u06cc \\u0628\\u0627\\u0634\\u062f.\"]}');

-- ----------------------------
-- Table structure for tour_category
-- ----------------------------
DROP TABLE IF EXISTS `tour_category`;
CREATE TABLE `tour_category`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `parent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `thumbnail` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `slider` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `show` tinyint(1) NULL DEFAULT 1,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `dom` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `slug`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of tour_category
-- ----------------------------
INSERT INTO `tour_category` VALUES (1, 1, 'استانبول', 'استانبول', 'ترکیه', '1621194202chosse6.jpg', '1621194202tour-detail2.jpg', '<section id=\"attraction\" class=\"sec\">\r\n<div class=\"container\">\r\n<div class=\"sec-head sec-head--rev\">\r\n<h1 class=\"sec-head__title\"><strong>معرفی استانبول</strong></h1>\r\n</div>\r\n<div class=\"TL-tour-intro-content\">\r\n<p>استانبول پایتخت فرهنگی کشور ترکیه می‌باشد که قرن‌ها پایتخت امپراطوری‌های مختلف بوده است؛ اما این شهر بیشتر شکوه و عظمت خود را مدیون امپراطوری قدرتمند عثمانی است. تمام آثار تاریخی به جا مانده از دوران عثمانی، مانند کاخ‌ها، مساجد و بناهای تاریخی، دارای معماری‌های خارق‌العاده و منحصر‌به‌فردی هستند که باعث محبوبیت تور استانبول در میان علاقه‌مندان به فرهنگ و هنر شده است. شهر استانبول علاوه بر جاذبه‌های تاریخی، به لطف داشتن تنگه‌ی بسفر و هم مرز بودن با قاره‌ی اروپا، دارای طبیعتی سرسبز و بی‌نظیر است. تمام این ویژگی‌های طبیعی و تاریخی استانبول را به یک مقصد توریستی جذاب برای گردشگران سراسر دنیا تبدیل کرده است. علاوه بر این احتیاج نداشتن به ویزا برای سفر به استانبول و کم بودن مدت پرواز و همچنین نزدیکی فرهنگی، محبوبیت تور استانبول را برای ما ایرانی‌ها چند برابر کرده است</p>\r\n<p> </p>\r\n</div>\r\n</div>\r\n</section>\r\n<section class=\"sec\">\r\n<div class=\"container\">\r\n<h2 class=\"sec-head__title\" style=\"text-align: center;\"><strong>بهترین مقاصد گردشگری و جاذبه‌های استانبول</strong></h2>\r\n<div class=\"sec-head sec-head--rev\">\r\n<div class=\"sec-head__desc\">مسجد ایاصوفیه – قصر توپکاپی – مسجد سلطان احمد – آب‌انبار باسیلیکا – برج گالاتا – موزه باستان‌شناسی استانبول – کاخ دلمه باغچه – مسجد سلیمانیه – مسجد رستم پاشا – موزه هنر مدرن استانبول – موزه هنرهای ترکی و اسلامی استانبول – قلعه یدیکوله استانبول – موزه پرا استانبول – اسکودار استانبول - قلعه‌ی روملی حصار – تنگه‌ی بسفر.</div>\r\n</div>\r\n<div class=\"TL-attraction-col\">\r\n<div class=\"row\">\r\n<div class=\"col-lg-12 d-flex flex-column\"> </div>\r\n<div class=\"col-lg-12 d-flex flex-column\">\r\n<div class=\"col-lg-12 d-flex flex-column\">\r\n<div class=\"TL-attraction-col__box\">\r\n<h3 class=\"TL-attraction-col__box-title\">تنگه‌ی بسفر - استانبول</h3>\r\n<div class=\"TL-attraction-col__box-desc\">تنگه‌بسفر، یکی از معروف‌ترین جاذبه‌ها‌ی طبیعی در بین گردشگران تور استانبول است که نه تنها مرز بین قاره‌ی اروپا و آسیا است. بلکه استانبول را نیز به دو بخش آسیایی و اروپایی تقسیم می‌کند. بهترین راه، برای کشف تمام زیبایی‌های تنگه و مناظر رویایی ترکیه، کشتی سواری بر روی تنگه بسفر است.</div>\r\n<div class=\"TL-attraction-col__box-desc\"> </div>\r\n<div class=\"TL-attraction-col__box-desc\">\r\n<h3 class=\"TL-attraction-col__box-title\">مسجد ایاصوفیه - استانبول</h3>\r\n<div class=\"TL-attraction-col\">\r\n<div class=\"row\">\r\n<div class=\"col-lg-12 d-flex flex-column\">\r\n<div class=\"TL-attraction-col__box\">\r\n<div class=\"TL-attraction-col__box-desc\">ایاصوفیه مسجدی عظیم و باشکوه است که نماد شهر استانبول نیز به شمار می‌رود. این بنا با معماری خاص خود در ابتدا یک کلیسا‌ی بزرگ بوده است؛ اما بعد از روی کار آمدن عثمانی‌ها به اصلی‌ترین محل عبادت مسلمانان تبدیل شد. ایا صوفیه درحال‌حاضر یکی از محبوب‌ترین جاذبه‌های تاریخی تور استانبول است.</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"TL-attraction\">\r\n<div class=\"row no-gutters TL-attraction__reverse TL-attraction__reverse--border\">\r\n<div class=\"col-lg-12\">\r\n<div class=\"TL-attraction__box\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"TL-attraction-col__box-desc\"> </div>\r\n</div>\r\n</div>\r\n<div class=\"col-lg-12 d-flex flex-column\"> </div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>', 1, '2021-04-10 18:14:18', '2021-05-17 00:13:23', NULL);
INSERT INTO `tour_category` VALUES (2, 1, 'دهلی', 'دهلی', 'هند', 'chosse6.jpg', '1621194124tour-detail2.jpg', '<p>سصبش س</p>\r\n<p>بسثب </p>\r\n<p>ثبلفذث</p>\r\n<p><img src=\"../image/uploads/unnamed.png\" alt=\"\" width=\"512\" height=\"512\"></p>\r\n<p>بثق</p>\r\n<p>دصقفصاقف</p>\r\n<p> </p>', 1, '2021-04-10 18:14:18', '2021-05-17 00:12:05', NULL);

-- ----------------------------
-- Table structure for tour_package
-- ----------------------------
DROP TABLE IF EXISTS `tour_package`;
CREATE TABLE `tour_package`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `single_price` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `double_price` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `baby_with_bed_price` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `baby_without_bed_price` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `baby_price` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `tip` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `facility` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `food` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `description` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `airline` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `show` tinyint(1) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 97 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tour_package
-- ----------------------------
INSERT INTO `tour_package` VALUES (94, 5, '3', '---', '---', '---', '---', '---', '---', '---', '---', '---', '', 0);
INSERT INTO `tour_package` VALUES (95, 5, '2', '---', '---', '---', '---', '---', '---', '---', '---', '---', '', 0);
INSERT INTO `tour_package` VALUES (96, 5, '1', '---', '---', '---', '---', '---', '---', '---', '---', '---', '', 0);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email_verified_at` datetime(0) NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'user',
  `user_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `email_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password_is_changed` tinyint(1) NOT NULL DEFAULT 0,
  `credit` bigint NOT NULL DEFAULT 0,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `status` tinyint NULL DEFAULT 1,
  `local_password` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `autosave_time` bigint NULL DEFAULT NULL,
  `delete` tinyint(1) NULL DEFAULT 0,
  `deleted_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_mobile_unique`(`mobile`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 32 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, '09369100696', 'vahid.majidi.sadr@gmail.com', '2021-02-02 00:08:17', 'majidi68', 'pwF6rJGVoNDMqzZEhABKiBKCuxlet5NifqThe2zvOrD5xQ4RQQptqyQ5uOQT', 'admin', NULL, 1, 'udnzmMEndtK1tehr', 1, 1000, '1900-01-20 17:17:39', '2021-05-02 19:25:41', 1, '2222', 5, 0, '2021-04-28 14:06:57');
INSERT INTO `users` VALUES (2, '09193109312', 'hr.ahmadi6722@gmail.com', '2021-01-26 17:49:10', 'asdasd', 'CEKgiJ35ws1Vru5OUfzIJOVhSX5vyUJ3kKd2e4DI8AqSHNtQQ19WYIuxBGfs', 'admin', NULL, 1, 'iLHzrDio4geT8xcB', 1, 0, '2021-01-26 16:18:12', '2021-05-01 10:22:28', 1, '6722', 22, 0, NULL);
INSERT INTO `users` VALUES (29, '09127632104', NULL, NULL, NULL, 'srOlxKkNMLGDTKSSwlqommu6Xx58MUI33KJdTWABLs8roZCw4xvvLUfo1dEb', 'admin', NULL, 0, NULL, 0, 0, '2021-04-12 12:18:48', '2021-04-12 12:18:48', 1, NULL, NULL, 0, NULL);
INSERT INTO `users` VALUES (30, '09123326799', NULL, NULL, NULL, 'vstijqb5fGQb6ZPbpqKICUPihBsMw0gVAguIUaTHWBGAfShC6asnQnCnTvT2', 'admin', NULL, 0, NULL, 0, 0, '2021-04-12 12:23:49', '2021-04-12 12:23:49', 1, NULL, NULL, 0, NULL);
INSERT INTO `users` VALUES (31, '09101764136', NULL, NULL, NULL, 'SGax4NgnvHxccVurWCH4qzYfAiCQKNyS5TwUn2zxkmyk8L1U1XlvV2dkLsck', 'admin', NULL, 0, NULL, 0, 0, '2021-04-25 10:58:49', '2021-04-25 10:58:49', 1, NULL, NULL, 0, NULL);

-- ----------------------------
-- Table structure for visa_category
-- ----------------------------
DROP TABLE IF EXISTS `visa_category`;
CREATE TABLE `visa_category`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `thumbnail` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `slider` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `show` tinyint(1) NULL DEFAULT 1,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `slug`(`slug`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of visa_category
-- ----------------------------
INSERT INTO `visa_category` VALUES (1, 1, 'تایلند', 'تایلند', 'image2.jpg', 'tour-detail2.jpg', '<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</p>\r\n<div class=\"good-now\">\r\n<h3> </h3>\r\n<p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوملورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</p>\r\n<ul>\r\n<li><label>موقعیت جغرافیایی</label>جنوب شرقی آسیا</li>\r\n<li><label>واحد پول</label>دانگ ویتنام</li>\r\n<li><label>زبان</label>ویتنامی، انگلیسی</li>\r\n<li><label>حمل و نقل</label>موتورسیکلت</li>\r\n</ul>\r\n</div>\r\n<div class=\"thing-to\">\r\n<h3>کارهایی که در ویتنام انجام می شود</h3>\r\n<p>از آنجا که ویتنام یک کشور بزرگ و متنوع است ، انبوهی از باورنکردنی وجود دارد کارهایی که باید انجام شود ، و این کشور را به یک کشور یک فروشگاهی برای فرهنگ و ماجراجویی تبدیل می کند لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</p>\r\n<div class=\"item\">\r\n<div class=\"title\">به سفر غذایی بروید</div>\r\n<div class=\"des\">ویتنام باید یکی از مکانهای مورد علاقه من برای غذاهای خیابانی باشد جنوب شرقی آسیا. بهترین چیز در مورد آن غذای خیابانی ارزان بودن خاک است غذایی به نام کاسه پو معتبر که فقط با 1 دلار شروع می شود.</div>\r\n</div>\r\n<div class=\"item\">\r\n<div class=\"title\">موتور یا دوچرخه اجاره کنید و به همه جا بروید</div>\r\n<div class=\"des\">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</div>\r\n</div>\r\n<div class=\"item\">\r\n<div class=\"title\">در یک بازی سنتی ویتنام شرکت کنید</div>\r\n<div class=\"des\">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</div>\r\n</div>\r\n<div class=\"item\">\r\n<div class=\"title\">هر غذای خیابانی بخورید</div>\r\n<div class=\"des\">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</div>\r\n</div>\r\n<div class=\"image clearfix\"><img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt1.jpg\" alt=\"tour\"> <img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt2.jpg\" alt=\"tour\"></div>\r\n<div class=\"item\">\r\n<div class=\"title\">از غذاهای سنتی ویتنام لذت ببرید</div>\r\n<div class=\"des\">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</div>\r\n</div>\r\n<div class=\"image2 clearfix\"><img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt3.jpg\" alt=\"tour\"></div>\r\n<h3>شهرداری ها</h3>\r\n<div class=\"des\">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</div>\r\n<div class=\"image3 clearfix\">\r\n<div class=\"item item1\"><img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt4.jpg\" alt=\"tour\"></div>\r\n<div class=\"item item2\"><img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt5.jpg\" alt=\"tour\"></div>\r\n<div class=\"item item2\"><img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt6.jpg\" alt=\"tour\"></div>\r\n<div class=\"item item2\"><img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt7.jpg\" alt=\"tour\"></div>\r\n<div class=\"item item2\"><img class=\"img-responsive\" src=\"../image/catalog/demo/product/travel/dt8.jpg\" alt=\"tour\"></div>\r\n</div>\r\n</div>', 1, NULL, '2021-04-11 16:15:39');
INSERT INTO `visa_category` VALUES (5, 1, 'کانادا', 'کانادا', '1618141845image2.jpg', '1618141845tour-detail2.jpg', '<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>\r\n<p>لورم ایپسوم</p>', 1, '2021-04-11 16:20:45', '2021-04-11 16:20:45');

SET FOREIGN_KEY_CHECKS = 1;
