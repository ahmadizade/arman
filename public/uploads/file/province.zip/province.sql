/*
 Navicat MySQL Data Transfer

 Source Server         : 193.141.65.54
 Source Server Type    : MariaDB
 Source Server Version : 100419
 Source Host           : 193.141.65.54:3306
 Source Schema         : netran_shop

 Target Server Type    : MariaDB
 Target Server Version : 100419
 File Encoding         : 65001

 Date: 07/06/2021 11:29:10
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for province
-- ----------------------------
DROP TABLE IF EXISTS `province`;
CREATE TABLE `province`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of province
-- ----------------------------
INSERT INTO `province` VALUES (1, 'آذربايجان شرقي');
INSERT INTO `province` VALUES (2, 'آذربايجان غربي');
INSERT INTO `province` VALUES (3, 'اردبيل');
INSERT INTO `province` VALUES (4, 'اصفهان');
INSERT INTO `province` VALUES (5, 'البرز');
INSERT INTO `province` VALUES (6, 'ايلام');
INSERT INTO `province` VALUES (7, 'بوشهر');
INSERT INTO `province` VALUES (8, 'تهران');
INSERT INTO `province` VALUES (9, 'چهارمحال بختياري');
INSERT INTO `province` VALUES (10, 'خراسان جنوبي');
INSERT INTO `province` VALUES (11, 'خراسان رضوي');
INSERT INTO `province` VALUES (12, 'خراسان شمالي');
INSERT INTO `province` VALUES (13, 'خوزستان');
INSERT INTO `province` VALUES (14, 'زنجان');
INSERT INTO `province` VALUES (15, 'سمنان');
INSERT INTO `province` VALUES (16, 'سيستان و بلوچستان');
INSERT INTO `province` VALUES (17, 'فارس');
INSERT INTO `province` VALUES (18, 'قزوين');
INSERT INTO `province` VALUES (19, 'قم');
INSERT INTO `province` VALUES (20, 'كردستان');
INSERT INTO `province` VALUES (21, 'كرمان');
INSERT INTO `province` VALUES (22, 'كرمانشاه');
INSERT INTO `province` VALUES (23, 'كهكيلويه و بويراحمد');
INSERT INTO `province` VALUES (24, 'گلستان');
INSERT INTO `province` VALUES (25, 'گيلان');
INSERT INTO `province` VALUES (26, 'لرستان');
INSERT INTO `province` VALUES (27, 'مازندران');
INSERT INTO `province` VALUES (28, 'مركزي');
INSERT INTO `province` VALUES (29, 'هرمزگان');
INSERT INTO `province` VALUES (30, 'همدان');
INSERT INTO `province` VALUES (31, 'يزد');

SET FOREIGN_KEY_CHECKS = 1;
