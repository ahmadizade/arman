/*
 Navicat Premium Data Transfer

 Source Server         : 193.141.65.54
 Source Server Type    : MySQL
 Source Server Version : 100419
 Source Host           : 193.141.65.54:3306
 Source Schema         : netran_shop

 Target Server Type    : MySQL
 Target Server Version : 100419
 File Encoding         : 65001

 Date: 05/06/2021 14:37:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email_verified_at` datetime(0) NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'user',
  `user_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `email_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password_is_changed` tinyint(1) NOT NULL DEFAULT 0,
  `credit` bigint NOT NULL DEFAULT 0,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `status` tinyint NULL DEFAULT 1,
  `local_password` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `autosave_time` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_mobile_unique`(`mobile`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 48 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, '09369100696', 'vahid.majidi.sadr@gmail.com', '2021-02-02 00:08:17', '$2y$10$b9LwwrN2eiMvJK1JuEh3g.cGfAO7iyyS/8zb8EMM2IIVEWJWIPO4S', 'CJrweI1t9mPCTvZ3PiaN7P4u26VBKuhqexmNmXCyq3d6zhm5SGHBM8UB1a72', 'admin', '', 1, 'udnzmMEndtK1tehr', 1, 1000, '1900-01-20 17:17:39', '2021-05-22 17:06:34', 1, '1234', 5);
INSERT INTO `users` VALUES (2, '09193109312', 'hr.ahmadi6722@gmail.com', '2021-01-26 17:49:10', '$2y$10$nNVSowA245EgvG3GSSz8DOuhFqfIpnkuOn5EV5bxZDyMeblaOwKqC', 'hGpgV618o6QzY2FOjOaEW2KAUCMywMcpwdtdi1Dt4WZtwknxEsSIxTFJI2oY', 'admin', NULL, 1, 'iLHzrDio4geT8xcB', 1, 0, '2021-01-26 16:18:12', '2021-04-01 19:08:54', 1, '6722', 22);
INSERT INTO `users` VALUES (3, '09190049170', 'mehdirajolani@gmail.com', '2021-04-08 20:03:39', '$2y$10$LFe3P.BXQcJQGA3L2AHkWuH5KKAE2YcNflrkrLKFGmdN08..5xwBu', 'sek13OAknZTdlMwEBVhITWvwR5lYOXsoQCZYh2SR4HVU6cvTHjs1lOz9K3FA', 'user', NULL, 1, 'iLasd3SwrgeT8xcB', 1, 0, '1900-01-20 17:17:39', '2021-03-13 19:48:37', 2, '2222', 10);
INSERT INTO `users` VALUES (4, '09370000207', 'nanaei.ehsan@gmail.com', NULL, '$2y$10$nNVSowA245EgvG3GSSz8DOuhFqfIpnkuOn5EV5bxZDyMeblaOwKqC', '8SgxYplDJvwue75VlCQ1TluDKtp843opBsPmu2QWOE3ATUI2UPVVLt8Ay1PA', 'admin', NULL, 1, 'aa2yGRFNqbxeVVog', 1, 1200, '2021-03-14 15:41:50', '2021-03-30 18:55:13', 1, '0000', 5);
INSERT INTO `users` VALUES (5, '09391533422', 'netran.rk@gmail.com', NULL, '$2y$10$b9LwwrN2eiMvJK1JuEh3g.cGfAO7iyyS/8zb8EMM2IIVEWJWIPO4S', '9P0IrBcTFB07lbqDmU27adGUI25yUFKjdiLheuXe0GxIb6H74CocBupLYI7g', 'user', NULL, 0, 'kxuRAsSOd5FUs2g8', 1, 0, '2021-03-14 15:45:39', '2021-03-28 16:49:53', 1, '1234', 5);
INSERT INTO `users` VALUES (8, '09212560822', NULL, NULL, '$2y$10$nYATBmNf/PUV6fAQ72rjq.6fJ9qU/l5bWVx8jiDdIMGAxeFPpucha', 'IUnT8SJjDR9pUR1XGqvajSX097pKeCPOT3DPB0ZIpz8ZPWVd8jNF16UeL9KT', 'user', NULL, 0, NULL, 0, 0, '2021-03-14 15:53:44', '2021-04-05 21:28:32', 1, NULL, 5);
INSERT INTO `users` VALUES (9, '09395176537', 'farnooshk78@gmail.com', '2021-04-21 10:45:21', '$2y$10$ma43twKYMcM6n3NDLtqMnOsWU8QBN0KkP/mP7p0XiHqSNw/qWyXIy', 'XHPaSEHqH2eX2OSTGWRzYobHDuBcXB5k0NAtKfkAO5c1kn1Oon682rE5zfhh', 'admin', NULL, 1, 'aRr3Cs2ucA671UF1', 0, 0, '2021-03-14 16:47:59', '2021-04-21 10:45:32', 1, '0000', 5);
INSERT INTO `users` VALUES (10, '09120342268', 'elnaztohidi7676@gmail.com', '2021-04-08 20:03:39', '$2y$10$dYQ4tXLqQWxtgCHERGzLBOJnLslS68t.5gpA3U8mLSkl8juSdc3wa', 'R9Rd30oQJlLeuhqNQxpvPCb2qFjkmktQmj5ZqiI9TcSgXQgRy0CdqGeyVzpZ', 'admin', NULL, 1, 'cujK5B5qN3oAHxef', 1, 0, '2021-03-14 16:55:40', '2021-05-12 17:01:36', 1, '0000', 5);
INSERT INTO `users` VALUES (11, '09368745832', 'mahasta.h71@gmail.com', NULL, '$2y$10$fb0hCsIujLFTBuKuvNgetObu6r/3hxH48JkynVnwA/f9G1LRVEQC2', 'HSqv8espsCwkEeYy9Bm3qZw6Vw5ZUMDyb1075c6zxCMh1SlaBgn3pOBXWIA9', 'admin', NULL, 0, 'JVc8igQ4hR5kxCOU', 0, 0, '2021-03-14 16:56:33', '2021-03-28 12:08:13', 1, '0000', 5);
INSERT INTO `users` VALUES (12, '09337113115', NULL, NULL, '$2y$10$NLcHqwzdH1M0E1Irp9EzEuf/KvPApx9WMME3VVk0gCYP7AFfNURb.', 'flxtBtGUWAsyyiZMFQGtWfgu4g1FI1hpBHqUMCorN4i26jq9u8Pjz4vEANqo', 'admin', NULL, 0, NULL, 0, 0, '2021-03-14 16:56:52', '2021-03-28 12:40:19', 1, '0000', 5);
INSERT INTO `users` VALUES (13, '09387964414', NULL, NULL, '$2y$10$4XDz/yirH0Ct.OxIeG6cle2RzoQznuarmrgUn8egFaOfhBXG3XBrq', 'VMt9rzlDBHzHtT7ZQlkROzCFzSrJWtzquiCZc0lH1V2HqgFM0IUCe5zuiFVL', 'author', NULL, 0, NULL, 0, 0, '2021-03-14 16:58:27', '2021-03-14 17:38:54', 2, '1365', 5);
INSERT INTO `users` VALUES (14, '09027241293', '', NULL, '$2y$10$oUGIalLNml6QWrYyjBrfwuIlOy1BMnb1505wy6bk5Q6HLyaYnDEJS', 'PMikeCkGu06jcfahwU4lpvATCWtMF7utKgVrkuWqt98AmSXhJ2Dz3ZvSm8W5', 'author', NULL, 0, NULL, 0, 0, '2021-03-14 16:58:34', '2021-03-14 16:58:34', 2, NULL, NULL);
INSERT INTO `users` VALUES (15, '09381972424', NULL, NULL, '$2y$10$au6We4HQySx2BXbdUq58U.UWOpRqsTXku7grlYDRr9jul7aOEB6NC', 'NE2qvHVy7BwZ2oF9tGX4f16ADRxYLpPHLx3GbjQ4YrrXcS93SCiLpgp4tGcn', 'author_head', NULL, 0, NULL, 0, 0, '2021-03-14 16:59:08', '2021-03-14 17:37:22', 1, '6470', 5);
INSERT INTO `users` VALUES (16, '09379438507', NULL, NULL, '$2y$10$XG0jkozbDKtra1z2rhLmd.Xza7b.hrgimJ7c3vfp16XT6ApK4lWFK', 'tLcl7xbQvVamyTzGWtUc6Nvklt8EmabwtFG8QwQMTXLjGGM4ih7K5PLF2E5j', 'author', NULL, 0, NULL, 0, 0, '2021-03-14 17:01:18', '2021-03-14 17:40:52', 1, '2626', 5);
INSERT INTO `users` VALUES (17, '09199926179', 'hamedamini7979@gmail.com', NULL, '$2y$10$7PBgWAEw60A3ToC/XWuI9ugx4Xo.axr53CO8v0HteqmUrksKyDkAe', 't5Rl5viAj6yNAatTFSHpTltObfg2F7MdIVTby8BwoaRC6ePsdvbsd1YGwDcg', 'user', NULL, 0, 'ihf4llJqS5paBVrC', 0, 0, '2021-03-14 17:19:58', '2021-03-14 17:52:36', 2, '1234', 5);
INSERT INTO `users` VALUES (18, '09125829853', NULL, NULL, '$2y$10$LJSuEnd2.JT6tcms2pPy2.ArKCs6.c5GLVtMZGy/0IzX545rgH0Wq', 'z1rZrQ8lrWCyq6yUrn0LXpK2iHmpGl9b4oIvaO358ReyFzAJ2glPIacotIOc', 'user', NULL, 0, NULL, 0, 0, '2021-03-14 17:37:08', '2021-04-14 10:14:47', 1, '6722', 5);
INSERT INTO `users` VALUES (19, '09212570939', NULL, NULL, '$2y$10$YKgxBYe7ufSE4HaYsAsiNOR/1fBYPVNBJovKPv/2v08DmLT./JQb2', 'g5tGGAnjwVNPuHqIu7PXTIAsWZQgDwuI9hG0AdJ4HZPbaQsDy13hNtSjyKR1', 'author', NULL, 0, NULL, 0, 0, '2021-03-14 17:37:40', '2021-03-14 17:40:29', 1, NULL, NULL);
INSERT INTO `users` VALUES (20, '09350725417', '', NULL, '$2y$10$ixQwZfA8qAesC90ZF0VvXuw4o1ZQLZhMc5TIvciaGUSwEQgN34PzK', 'y4Z3YW00ae4yd7EMLzftkAy0WO9VGfR7bFVAGWSaYCbmvgFWSQpbthA1BFSm', 'author', NULL, 0, NULL, 0, 0, '2021-03-14 17:45:09', '2021-03-14 17:45:09', 1, NULL, NULL);
INSERT INTO `users` VALUES (22, '09031352936', NULL, NULL, '$2y$10$xfhR.A6L4sliMEbG./tSTe.LQsNa3BgtwFUy.zRQzwcgSbSOFtRvq', '5r4huaE14gaKD0etetCf545wJ5uGWCTqN4cNSfrmxV6e0RSI1SmvQc6vogf1', 'user', NULL, 0, NULL, 0, 0, '2021-03-14 19:35:14', '2021-03-14 19:35:33', 2, NULL, NULL);
INSERT INTO `users` VALUES (23, '09352545495', NULL, NULL, '$2y$10$TpqIfi7u07RDS57MkJH4xunqne3M1PpTABlqabfe.3tcBeoh1FgeO', 'Iugk8LFYdmMSeJqTQumfdoz0YzooWbUz2rb64KaBO8uy0BQroT6Q88iYFHEW', 'seller_admin', NULL, 0, NULL, 0, 0, '2021-03-16 14:00:51', '2021-05-29 15:58:08', 1, NULL, 5);
INSERT INTO `users` VALUES (25, '09212882168', NULL, NULL, '$2y$10$LeOPC1r8DMJoG6KJqHMZ0uO69uJzcWUv72uWj0EcyzDQROvRmqc2i', 'v5mrlFmM9bh4C295XCCRjy1NZFkTDqxsyebXnT8d1cbqp3lv4Ixps59XJVRo', 'seller_admin', NULL, 0, NULL, 1, 0, '2021-03-16 14:01:53', '2021-05-29 15:57:55', 1, '1525', 5);
INSERT INTO `users` VALUES (26, '09915236819', 'javadmoosavi376@gmail.com', NULL, '$2y$10$0mLHDMkioYygKwh2ShbRNezaggH4uMG0lzK2DMSS0fHyvW9HHnru.', 'Netranl', 'seller_admin', NULL, 0, 'PT3IgPlajsKKxgt4', 1, 0, '2021-04-01 12:46:08', '2021-05-29 16:17:40', 1, '1234', 5);
INSERT INTO `users` VALUES (27, '09354514203', 'mehdi.mohebi536@gmail.com', NULL, '$2y$10$.DKUNBhKDyU4RRxFd3x4b.klenBp51682h6Zzy03AgjKHCy3EVtz.', 'g31mmjUVUOhUZpLmgBBibHQU3osTxdqvO45IcA1FyOaDThwVupoHAKemu0HR', 'seller_admin', NULL, 0, 'sOF4rqWYz7rX15sR', 0, 0, '2021-04-04 16:12:52', '2021-05-29 15:55:37', 1, NULL, 5);
INSERT INTO `users` VALUES (28, '09381500731', 'khdaprstmhrshad@gmail.com', NULL, '$2y$10$bG.dVEuD2ZwN9mT/Q4jX/.tPkMTtvMZLLg6sXMtpUiwRQoAWduXda', 'bVTVhL3I6O9Y8hAhnmHBO0Bdb87GuAfObdjGoSmFIALcRS1C9glcw350fLyE', 'seller_admin', NULL, 0, 'm9Xr7mh6jx9nEi2z', 0, 0, '2021-04-04 16:15:41', '2021-05-29 15:55:26', 1, NULL, 5);
INSERT INTO `users` VALUES (29, '09010000593', 'masoodmanaee@gmail.com', NULL, '$2y$10$hhmolCAwa.nnIJ1lUqqkXuXkHe7/AnmTqneklmUuLIrKoKTNip6Km', 'CBhbFgwKsX4h6D8M3esLa38OSKYjiBceQiZrly2vR848BDfRFNoab6Q2pHpq', 'admin', NULL, 0, 'uOGCPcEkt30L6Y4o', 1, 0, '2021-04-04 16:43:24', '2021-04-04 17:34:17', 1, NULL, 5);
INSERT INTO `users` VALUES (30, '09022221763', 'kiarashaghkalam@yahoo.com', NULL, '$2y$10$vsWwuFhPNtAplZ2S7V6Op.o/8TJbWIrUiIDsS0a2ML1.Z1YbqHwP2', 'E7HIVylhxzNRjbUx4iuxc40HqrcLUfnkD0zoblaIfsmQ0QPKTv2VWTRU2iTK', 'seller_admin', NULL, 0, 'wVqr61sIw5ECllQg', 1, 0, '2021-04-05 09:44:05', '2021-05-29 15:54:49', 1, '0090', 5);
INSERT INTO `users` VALUES (35, '09010000592', NULL, NULL, '$2y$10$mseA0zqvDdIQNZT6zw52f.ymq/DHDaGPi0ApW5GelL9B4Ym73oBPi', NULL, 'user', NULL, 0, NULL, 0, 0, '2021-04-08 04:40:14', '2021-04-08 04:40:14', 1, NULL, NULL);
INSERT INTO `users` VALUES (36, '09123269304', NULL, NULL, '$2y$10$DjORqFsVdZPdrRY3sJpBC.SAsnXysAohx82XdjH69aQq2yC1dXfoe', NULL, 'user', NULL, 0, NULL, 0, 0, '2021-04-08 04:40:59', '2021-04-08 04:40:59', 1, NULL, NULL);
INSERT INTO `users` VALUES (37, '09355241678', '', NULL, '$2y$10$g1VNKaqIefWnskjnbmMUt.zA3wbJKU5YgN9pHpGUtg2.GxdOkcIni', 'Xy9qIeY6gf67ckigswpFr508CgufRDbfKRQQt2kxNCbni14bISMF8ZnT6i03', 'user', 'company', 0, NULL, 1, 0, '2021-04-10 16:19:13', '2021-04-10 16:30:32', 1, NULL, NULL);
INSERT INTO `users` VALUES (38, '09391618464', '', NULL, '$2y$10$C4YCqwHR4.UfB3JqPmS2PeEmKzxUpgSXV43r1e2v2Ubtt2y70LQ9i', 'pc7GQspQRQf9wUDIHNhDOG5hlVqJpej4Xrb9EzesZYrH3GpVmxxVOz1CVhZ7', 'user', NULL, 0, NULL, 1, 0, '2021-04-10 17:36:47', '2021-04-10 17:37:17', 1, NULL, NULL);
INSERT INTO `users` VALUES (39, '09223165366', NULL, NULL, '$2y$10$EHmZMAvb/IeXdef9t//A7.pNfr3JuCY8uv1X0TJgvgtqxhsAnp7qm', 'btuP7DRBB4FMfeEqwmHS69rYfOc8CDPCWRVJt0BE2p1IT0FcVoi9MQ2ZelLO', 'user', NULL, 0, NULL, 0, 0, '2021-04-11 16:27:26', '2021-04-17 11:57:35', 1, NULL, 5);
INSERT INTO `users` VALUES (41, '09032735306', '', NULL, '$2y$10$Qq4T47qcMDFkZDF8atWQ2e5zgbsbj5i6pDS6kxUtVV/9IYYUDPdXO', 'FEP16FamVOWn6BjqFg72wbXKxlfU4cuwJkWn1wmTJLmzdisiIf7c5qFqJhVY', 'user', NULL, 0, NULL, 0, 0, '2021-04-12 10:31:06', '2021-04-12 10:31:06', 1, NULL, NULL);
INSERT INTO `users` VALUES (42, '09359312383', '', NULL, '$2y$10$AHEuzLpxo445ZEE7IFQnO.snl8czfaZQFMRAx/.tkBIoeWd3Z.q/6', 'ucylOwqFrKlubLWKvrWnTNWQGjKqWV0c2AadW92tBXiEFgCW3J9pK6ppoTGY', 'user', NULL, 0, NULL, 0, 0, '2021-04-14 22:19:18', '2021-04-14 22:19:18', 1, NULL, NULL);
INSERT INTO `users` VALUES (44, '09127167122', NULL, NULL, '$2y$10$CRCjoYyrgqkMmQ3BZubomO62RqFHElkuHAm6UTLfhXfYXAxNwF1h6', NULL, 'user', '', 0, NULL, 0, 0, '2021-04-24 22:22:51', '2021-04-28 09:07:44', 1, NULL, 5);
INSERT INTO `users` VALUES (45, '09105911378', NULL, NULL, '$2y$10$z2qidiCLhtnLqJksUNSLWeKqxF6/0bWtBkE29gAsRpvHVf5zS.2KG', 'YS1LrOSHRoAMHwgEeRCkNSbAx8gIDhyU438UXIlAhe7pVwmQ7JrbetK5lZgP', 'user', NULL, 0, NULL, 1, 0, '2021-04-26 23:45:44', '2021-05-06 14:22:28', 1, NULL, NULL);
INSERT INTO `users` VALUES (46, '09353059618', 'bahmaniyegan@gmail.com', '2021-05-11 15:48:16', '$2y$10$4lASEjNpvA4LxdHQ/LpLjurMHE/JSe80ornkvbGf6.wS4P9722USW', 'WtOoTdJhh4dJFMSSjBg4tHzbVg9IQ13J5EC8fcMeB8BjpmsYXBBVlMucOgXh', 'user', '', 1, 'mOoVdCQhxhpmsAVz', 1, 0, '2021-05-11 15:40:17', '2021-05-29 17:16:05', 1, NULL, 5);
INSERT INTO `users` VALUES (47, '09126155671', NULL, NULL, '$2y$10$O..0ybRUDzmIsOTI5UqAyug34mp4KBRq9ihhj4YRUpSliQEGIwNLu', 'cF7doQ9MVAdeZ6xvuBzkyKCklZKoDhaggbOsQmnieFGwvYVI4z6Y05qzJqMw', 'admin', '', 0, NULL, 0, 0, '2021-05-15 09:26:52', '2021-06-03 11:45:04', 1, '1234', 5);

SET FOREIGN_KEY_CHECKS = 1;
