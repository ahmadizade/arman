<div style="border:1px solid #ccc;padding: 25px;width: 100%;">
    <h3 style="text-align: center;">{{ $result['title'] }}</h3>
    <hr>
    <p style="text-align: right">{{ $result['content'] }}</p>
    <hr>
</div>




