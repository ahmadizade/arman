<div style="border: 1px solid #ccc;padding: 20px;box-sizing: border-box;margin: 25px 0;box-shadow: 0 15px 10px -10px #ccc;">
    <p style="text-align: center"><img style="max-width: 100%" src="http://cioceiran.com/images/logo/logo_100_50.png" alt="SaminTakhfif"></p>
    <h1 style="margin: 35px 0 0 0;text-align: center;font-size: 15px;font-family: tahoma">جهت تایید ایمیل خود در وب سایت فروشگاه سی و سه روی لینک زیر کلیک کنید</h1>
    <h6 style="margin: 20px 0 10px 0;text-align: center"><a style="font-size: 13px;border: 1px solid #15c;padding: 5px 10px;text-decoration: none;font-family: tahoma" href="{{ $result['content'] }}">تایید ایمیل</a></h6>
</div>
