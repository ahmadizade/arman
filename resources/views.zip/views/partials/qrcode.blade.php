<!doctype html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CioCe.ir | فروشگاه سی و سه</title>
</head>
<body>
<div>
    @if(isset($data))
        <img src="https://api.qrserver.com/v1/create-qr-code/?data={{$data}}" alt="" title=""/>
    @else
        <p>Set Nashode</p>
    @endif
</div>
</body>
</html>








