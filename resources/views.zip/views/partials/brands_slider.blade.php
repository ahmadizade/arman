<!-- Start Brand-Slider -->
<section class="slider-section dt-sl mb-5">
    <div class="row">
        <!-- Start Product-Slider -->
        <div class="col-12">
            <div class="brand-slider carousel-lg owl-carousel owl-theme">
                <div class="item">
                    <img src="/img/brand/1076.png" class="img-fluid" alt="">
                </div>
                <div class="item">
                    <img src="/img/brand/1078.png" class="img-fluid" alt="">
                </div>
                <div class="item">
                    <img src="/img/brand/1080.png" class="img-fluid" alt="">
                </div>
                <div class="item">
                    <img src="/img/brand/2315.png" class="img-fluid" alt="">
                </div>
                <div class="item">
                    <img src="/img/brand/1086.png" class="img-fluid" alt="">
                </div>
                <div class="item">
                    <img src="/img/brand/5189.png" class="img-fluid" alt="">
                </div>
                <div class="item">
                    <img src="/img/brand/1000006973.png" class="img-fluid" alt="">
                </div>
                <div class="item">
                    <img src="/img/brand/1000014452.jpg" class="img-fluid" alt="">
                </div>
            </div>
        </div>
        <!-- End Product-Slider -->

    </div>
</section>
<!-- End Brand-Slider -->
