<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body style="background: url(/images/gif/comingsoon.gif);background-size: cover;background-repeat: no-repeat;background-position: bottom bottom;">
<div class="container">
    <div class="row">
        <div class="col-12 text-center mt-5">
            <h1>Maintenance! Mode</h1>
            <h5>This site will open at the end of 2021</h5>
            <p class="font-14 mt-2"><b>CioCe</b> Support <b>Team</b></p>
        </div>
    </div>
</div>
</body>

</html>
