                <p>jshgdoiufhdrtgoiurehgiuheriughiudrhgu</p>
@if(isset($id))
    <p>{{$id}}</p>
    @endif
{{--@extends("admin.layouts.master")--}}
{{--@section("title")--}}
{{--    <title>CioCe.ir | فروشگاه سی و سه</title>--}}
{{--@endsection--}}
{{--@section("extra_css")--}}
{{--    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">--}}
{{--    --}}{{--    <link rel="stylesheet" type="text/css" href="/admin/css/buttons.dataTables.min.css">--}}
{{--@endsection--}}
{{--@section("content")--}}
{{--    <!-- Page Wrapper -->--}}
{{--    <div id="wrapper">--}}
{{--    @include("admin.partials.sidebar")--}}

{{--    <!-- Content Wrapper -->--}}


{{--        <div id="content-wrapper" class="d-flex flex-column">--}}

{{--            <!-- Main Content -->--}}
{{--            <div id="content">--}}


{{--                <!-- Begin Page Content -->--}}
{{--                <div class="container-fluid">--}}
{{--                </div>--}}


{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}

{{--@endsection--}}
