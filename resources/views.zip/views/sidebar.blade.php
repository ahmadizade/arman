<div class="col-12 col-lg-3">
    <div class="row">
        <div class="col-12">پرفروشترین ها</div>
    </div>
    <div class="row">
        <div class="col-12">بهترین فروشنده ها</div>
    </div>
    <div class="row">
        <div class="col-12">آخرین کاربران</div>
    </div>
</div>
